package pe.edu.pucp.johannmorales.thesis.connector.expose.web;

import org.springframework.web.bind.annotation.RestController;

@RestController
public class GreyWolfController {

}
