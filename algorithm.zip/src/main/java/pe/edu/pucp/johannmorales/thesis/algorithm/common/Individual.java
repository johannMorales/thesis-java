package pe.edu.pucp.johannmorales.thesis.algorithm.common;

import java.math.BigDecimal;
import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public abstract class Individual {

  private BigDecimal fitness;

}
