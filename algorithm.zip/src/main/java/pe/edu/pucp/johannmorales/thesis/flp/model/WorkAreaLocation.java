package pe.edu.pucp.johannmorales.thesis.flp.model;

import java.math.BigDecimal;

public class WorkAreaLocation {

  public BigDecimal x;

  public BigDecimal y;

}
