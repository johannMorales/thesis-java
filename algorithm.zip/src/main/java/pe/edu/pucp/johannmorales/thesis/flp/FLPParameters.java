package pe.edu.pucp.johannmorales.thesis.flp;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public final class FLPParameters {

  public int maxX;
  public int maxY;

}
