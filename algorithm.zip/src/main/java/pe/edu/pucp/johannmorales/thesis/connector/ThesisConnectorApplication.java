package pe.edu.pucp.johannmorales.thesis.connector;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ThesisConnectorApplication {

	public static void main(String[] args) {
		SpringApplication.run(ThesisConnectorApplication.class, args);
	}

}
